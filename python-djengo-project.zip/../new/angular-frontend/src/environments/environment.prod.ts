export const environment = {
  production: true,
  api_url: 'http://3.233.233.143:8000/api'
};
